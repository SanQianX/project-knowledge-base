// _site/_test/run-all-tests.js
//
// Single-command regression suite runner. Iterates the canonical test files
// under _site/_test/ (everything matching *-test.js) and runs each one in a
// separate child process, capturing exit code, duration, and the last few
// lines of output. Writes a Markdown report to TEST-REPORT.md.
//
// Usage:
//   node _site/_test/run-all-tests.js                  # run all *-test.js
//   node _site/_test/run-all-tests.js --no-report      # do not write report
//
// Exit code is 0 only if every test passes.

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..', '..');
const TEST_DIR = __dirname;
const REPORT_PATH = path.join(TEST_DIR, 'TEST-REPORT.md');

const args = process.argv.slice(2);
const WRITE_REPORT = !args.includes('--no-report');
const PER_TEST_TIMEOUT_MS = Number(process.env.PK_TEST_TIMEOUT_MS || 90_000);

function listTestFiles() {
  return fs.readdirSync(TEST_DIR)
    .filter(file => file.endsWith('-test.js'))
    .filter(file => file !== 'run-all-tests.js')
    .sort();
}

function tail(text, lines = 12) {
  const arr = String(text || '').split(/\r?\n/).filter(Boolean);
  return arr.slice(-lines).join('\n');
}

function classifyFailure(result) {
  if (result.status !== null) {
    return { kind: 'exit', label: `FAIL (exit ${result.status})` };
  }
  if (result.error && result.error.code === 'ETIMEDOUT') {
    return { kind: 'timeout', label: `TIMEOUT (killed after ${PER_TEST_TIMEOUT_MS}ms, signal ${result.signal || 'none'})` };
  }
  const code = result.error && result.error.code ? result.error.code : 'unknown';
  return { kind: 'error', label: `FAIL (spawn error ${code}, signal ${result.signal || 'none'})` };
}

function runOne(file) {
  const start = Date.now();
  // Every test child gets its own Bridge journal sandbox so hook-trigger /
  // server runtimes never touch the developer's ~/.ai-coding-event-bridge.
  const bridgeHome = fs.mkdtempSync(path.join(os.tmpdir(), `kb-runall-bridge-${process.pid}-`));
  const result = spawnSync(process.execPath, [path.join(TEST_DIR, file)], {
    cwd: ROOT,
    encoding: 'utf-8',
    timeout: PER_TEST_TIMEOUT_MS,
    env: { ...process.env, FORCE_COLOR: '0', AI_CODING_EVENT_BRIDGE_HOME: bridgeHome, KB_MODULES_AUTOSTART: '0' },
  });
  try { fs.rmSync(bridgeHome, { recursive: true, force: true, maxRetries: 3, retryDelay: 100 }); } catch {}
  const failure = result.status === 0 ? null : classifyFailure(result);
  return {
    file,
    passed: result.status === 0,
    failureKind: failure ? failure.kind : null,
    failureLabel: failure ? failure.label : null,
    exitCode: result.status,
    signal: result.signal,
    spawnErrorCode: result.error && result.error.code ? result.error.code : null,
    durationMs: Date.now() - start,
    stdout: result.stdout || '',
    stderr: result.stderr || '',
    outputTail: tail(`${result.stdout || ''}\n${result.stderr || ''}`.trim()),
  };
}

(async () => {
  const files = listTestFiles();
  console.log(`Running ${files.length} test file(s)...\n`);

  const results = [];
  let totalDuration = 0;
  for (const file of files) {
    process.stdout.write(`> ${file} ... `);
    const result = runOne(file);
    totalDuration += result.durationMs;
    results.push(result);

    if (result.passed) {
      console.log(`PASS (${result.durationMs}ms)`);
    } else {
      console.log(`${result.failureLabel}, ${result.durationMs}ms`);
      if (result.outputTail) {
        console.log('--- tail ---');
        console.log(result.outputTail);
        console.log('--- end tail ---');
      }
    }
  }

  const passed = results.filter(result => result.passed).length;
  const failed = results.length - passed;
  console.log('\n=========================================');
  console.log(`Regression suite: ${passed} passed, ${failed} failed (${totalDuration}ms total)`);
  console.log('=========================================\n');

  if (WRITE_REPORT) {
    const lines = [];
    lines.push('# KB Management Site Regression Test Report');
    lines.push('');
    lines.push(`**Generated**: ${new Date().toISOString()}`);
    lines.push(`**Node**: ${process.version}`);
    lines.push('**Runner**: node _site/_test/run-all-tests.js');
    lines.push('');
    lines.push('## Summary');
    lines.push('');
    lines.push(`**Per-test timeout**: ${PER_TEST_TIMEOUT_MS}ms (override with PK_TEST_TIMEOUT_MS)`);
    lines.push('');
    lines.push('| # | File | Status | Exit | Duration |');
    lines.push('|--:|------|:------:|-----:|---------:|');
    results.forEach((result, index) => {
      const status = result.passed ? 'PASS' : (result.failureKind === 'timeout' ? 'TIMEOUT' : 'FAIL');
      const exit = result.passed
        ? String(result.exitCode)
        : `${result.exitCode}${result.signal ? `, signal ${result.signal}` : ''}${result.spawnErrorCode ? `, error ${result.spawnErrorCode}` : ''}`;
      lines.push(`| ${index + 1} | \`${result.file}\` | ${status} | ${exit} | ${result.durationMs}ms |`);
    });
    lines.push('');
    lines.push(`**Total**: ${results.length} | **Passed**: ${passed} | **Failed**: ${failed} | **Time**: ${totalDuration}ms`);
    lines.push('');

    const failures = results.filter(result => !result.passed);
    if (failures.length) {
      lines.push('## Failures');
      lines.push('');
      for (const result of failures) {
        lines.push(`### ${result.file}`);
        lines.push('');
        lines.push('```');
        lines.push(result.outputTail);
        lines.push('```');
        lines.push('');
      }
    }

    try {
      fs.writeFileSync(REPORT_PATH, lines.join('\n'), 'utf-8');
      console.log(`Report written to: ${REPORT_PATH}`);
    } catch (e) {
      console.error(`Failed to write report: ${e.message}`);
    }
  }

  process.exit(failed > 0 ? 1 : 0);
})();
