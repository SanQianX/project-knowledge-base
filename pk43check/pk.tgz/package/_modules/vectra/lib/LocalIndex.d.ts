import { IndexItem, IndexStats, MetadataFilter, MetadataTypes, QueryResult } from './types';
import { FileStorage } from './storage';
import { IndexCodec } from './codecs';
export interface CreateIndexConfig {
    version: number;
    deleteIfExists?: boolean;
    metadata_config?: {
        indexed?: string[];
    };
}
/**
 * Local vector index instance.
 * @remarks
 * This class is used to create, update, and query a local vector index.
 * Each index is a folder on disk containing an index.json file and an optional set of metadata files.
 */
export declare class LocalIndex<TMetadata extends Record<string, MetadataTypes> = Record<string, MetadataTypes>> {
    private readonly _folderPath;
    private readonly _indexName;
    private readonly _storage;
    private readonly _codec;
    private _data?;
    private _update?;
    private _bm25Engine;
    private readonly _bm25Factory;
    private readonly _docReader;
    /**
     * Creates a new instance of LocalIndex.
     * @param folderPath Path to the index folder.
     * @param indexName Optional index file name. Defaults to 'index' + codec.extension.
     * @param storage Optional file storage instance. Defaults to LocalFileStorage.
     * @param codec Optional codec for serialization. Defaults to JsonCodec.
     * @param options Optional constructor options for dependency injection.
     */
    constructor(folderPath: string, indexName?: string, storage?: FileStorage, codec?: IndexCodec, options?: {
        bm25Factory?: () => any;
        docReader?: (docId: string) => Promise<string>;
    });
    /** Path to the index folder. */
    get folderPath(): string;
    /** Name of the index file. */
    get indexName(): string;
    /** Storage provider used to store the index. */
    get storage(): FileStorage;
    /** Codec used for serialization. */
    get codec(): IndexCodec;
    /**
     * Begins an update to the index.
     * @remarks
     * This method loads the index into memory and prepares it for updates.
     */
    beginUpdate(): Promise<void>;
    /**
     * Cancels an update to the index.
     * @remarks
     * This method discards any changes made to the index since the update began.
     */
    cancelUpdate(): void;
    /**
     * Creates a new index.
     * @remarks
     * This method creates a new folder on disk containing an index.json file.
     * @param config Index configuration.
     */
    createIndex(config?: CreateIndexConfig): Promise<void>;
    /**
     * Deletes the index.
     * @remarks
     * This method deletes the index folder from disk.
     */
    deleteIndex(): Promise<void>;
    /**
     * Deletes an item from the index.
     * @param id ID of item to delete.
     */
    deleteItem(id: string): Promise<void>;
    /**
     * Deletes a batch of items from the index in a single O(N) pass over the
     * items array.
     * @remarks
     * Functionally equivalent to calling `deleteItem` for each id, but avoids the
     * O(N·M) cost of repeated linear scans + splices when removing many items.
     * Like `deleteItem`, ids that don't exist are silently ignored.
     * @param ids IDs of items to delete.
     */
    deleteItems(ids: Iterable<string>): Promise<void>;
    /**
     * Ends an update to the index.
     * @remarks
     * This method saves the index to disk.
     */
    endUpdate(): Promise<void>;
    /**
     * Loads an index from disk and returns its stats.
     * @returns Index stats.
     */
    getIndexStats(): Promise<IndexStats>;
    /**
     * Returns an item from the index given its ID.
     * @param id ID of the item to retrieve.
     * @returns Item or undefined if not found.
     */
    getItem<TItemMetadata extends TMetadata = TMetadata>(id: string): Promise<IndexItem<TItemMetadata> | undefined>;
    /**
     * Adds an item to the index.
     * @remarks
     * A new update is started if one is not already in progress. If an item with the same ID
     * already exists, an error will be thrown.
     * @param item Item to insert.
     * @returns Inserted item.
     */
    insertItem<TItemMetadata extends TMetadata = TMetadata>(item: Partial<IndexItem<TItemMetadata>>): Promise<IndexItem<TItemMetadata>>;
    /**
     * Adds a batch of items to the index.
     * @remarks
     * Batch update requires no update to be in progress. This is necessary so that if any one
     * insert operation fails, the entire update can be safely cancelled. This prevents partial
     * updates from being applied to the local index.
     * @param items Items to insert.
     * @returns Inserted items.
     */
    batchInsertItems<TItemMetadata extends TMetadata = TMetadata>(items: Partial<IndexItem<TItemMetadata>>[]): Promise<IndexItem[]>;
    /** Returns true if the index exists. */
    isIndexCreated(): Promise<boolean>;
    /**
     * Returns all items in the index.
     * @remarks
     * This method loads the index into memory and returns all its items. A copy of the items
     * array is returned so no modifications should be made to the array.
     * @returns Array of all items in the index.
     */
    listItems<TItemMetadata extends TMetadata = TMetadata>(): Promise<IndexItem<TItemMetadata>[]>;
    /**
     * Returns all items in the index matching the filter.
     * @remarks
     * This method loads the index into memory and returns all its items matching the filter.
     * @param filter Filter to apply.
     * @returns Array of items matching the filter.
     */
    listItemsByMetadata<TItemMetadata extends TMetadata = TMetadata>(filter: MetadataFilter): Promise<IndexItem<TItemMetadata>[]>;
    /**
     * Finds the top k items in the index that are most similar to the vector.
     * @remarks
     * This method loads the index into memory and returns the top k items that are most similar.
     * An optional filter can be applied to the metadata of the items.
     * @param vector Vector to query against.
     * @param query Query string (used when isBm25=true).
     * @param topK Number of items to return.
     * @param filter Optional. Filter to apply.
     * @param isBm25 Optional. If true, append BM25 keyword results to semantic results.
     * @returns Similar items to the vector that match the supplied filter.
     */
    queryItems<TItemMetadata extends TMetadata = TMetadata>(vector: number[], query: string, topK: number, filter?: MetadataFilter, isBm25?: boolean): Promise<QueryResult<TItemMetadata>[]>;
    /**
     * Adds or replaces an item in the index.
     * @remarks
     * A new update is started if one is not already in progress. If an item with the same ID
     * already exists, it will be replaced.
     * @param item Item to insert or replace.
     * @returns Upserted item.
     */
    upsertItem<TItemMetadata extends TMetadata = TMetadata>(item: Partial<IndexItem<TItemMetadata>>): Promise<IndexItem<TItemMetadata>>;
    /** Ensures that the index has been loaded into memory. */
    protected loadIndexData(): Promise<void>;
    private addItemToUpdate;
    private setupBm25;
    private bm25Search;
}
//# sourceMappingURL=LocalIndex.d.ts.map