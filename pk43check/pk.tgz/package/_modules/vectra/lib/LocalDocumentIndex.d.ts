import { CreateIndexConfig, LocalIndex } from "./LocalIndex";
import { TextSplitterConfig } from "./TextSplitter";
import { MetadataFilter, EmbeddingsModel, Tokenizer, MetadataTypes, DocumentChunkMetadata, DocumentCatalogStats } from "./types";
import { LocalDocumentResult } from './LocalDocumentResult';
import { LocalDocument } from './LocalDocument';
import { FileStorage } from './storage';
import { IndexCodec } from './codecs';
/**
 * Options for querying documents in the index.
 */
export interface DocumentQueryOptions {
    /**
     * Optional. Maximum number of documents to return.
     * @remarks
     * Default is 10.
     */
    maxDocuments?: number;
    /**
     * Maximum number of chunks to return per document.
     * @remarks
     * Default is 50.
     */
    maxChunks?: number;
    /**
     * Optional. Filter to apply to the document metadata.
     */
    filter?: MetadataFilter;
    /**
     * Optional. Turn on bm25 keyword search to perform hybrid search - semantic + keyword
     */
    isBm25?: boolean;
}
/**
 * Configuration settings for a local document index.
 */
export interface LocalDocumentIndexConfig {
    /**
     * Folder path where the index is stored.
     */
    folderPath: string;
    /**
     * Optional. Name of the index file. Defaults to 'index.json'.
     */
    indexName?: string;
    /**
     * Optional. Embeddings model to use for generating document embeddings.
     */
    embeddings?: EmbeddingsModel;
    /**
     * Optional. Tokenizer to use for splitting text into tokens.
     */
    tokenizer?: Tokenizer;
    /**
     * Optional. Configuration settings for splitting text into chunks.
     */
    chunkingConfig?: Partial<TextSplitterConfig>;
    /**
     * Optional. File storage plugin to use for storing index files.
     * @remarks
     * If not specified, the LocalFileStorageClass will be used.
     */
    storage?: FileStorage;
    /**
     * Optional. Codec for serialization format.
     * @remarks
     * If not specified, the JsonCodec will be used (backward-compatible).
     */
    codec?: IndexCodec;
}
/**
 * Represents a local index of documents stored on disk.
 */
export declare class LocalDocumentIndex extends LocalIndex<DocumentChunkMetadata> {
    private readonly _embeddings?;
    private readonly _tokenizer;
    private readonly _chunkingConfig?;
    private _catalog?;
    private _newCatalog?;
    /**
     * Creates a new `LocalDocumentIndex` instance.
     * @param config Configuration settings for the document index.
     */
    constructor(config: LocalDocumentIndexConfig);
    /**
     * Returns the embeddings model used by the index (if configured.)
     */
    get embeddings(): EmbeddingsModel | undefined;
    /**
     * Returns the tokenizer used by the index.
     */
    get tokenizer(): Tokenizer;
    /**
     * Returns true if the document catalog exists.
     */
    /** Name of the catalog file (derived from codec extension). */
    private get _catalogName();
    isCatalogCreated(): Promise<boolean>;
    /**
     * Returns the document ID for the given URI.
     * @param uri URI of the document to lookup.
     * @returns Document ID or undefined if not found.
     */
    getDocumentId(uri: string): Promise<string | undefined>;
    /**
     * Returns the document URI for the given ID.
     * @param documentId ID of the document to lookup.
     * @returns Document URI or undefined if not found.
     */
    getDocumentUri(documentId: string): Promise<string | undefined>;
    /**
     * Loads the document catalog from disk and returns its stats.
     * @returns Catalog stats.
     */
    getCatalogStats(): Promise<DocumentCatalogStats>;
    /**
     * Deletes a document from the index.
     * @param uri URI of the document to delete.
     */
    deleteDocument(uri: string): Promise<void>;
    /**
     * Adds a document to the catalog.
     * @remarks
     * A new update is started if one is not already in progress. If a document with the same uri
     * already exists, it will be replaced — unless its stored content hash matches the new content,
     * in which case the call is a no-op and the existing document handle is returned. Pass
     * `options.force = true` to bypass the hash check and force a re-embed (useful after rotating
     * the embeddings model).
     * @param uri - Document URI
     * @param text - Document text
     * @param docType - Optional. Document type
     * @param metadata - Optional. Document metadata to index
     * @param options - Optional. `force: true` skips the skip-if-unchanged check.
     * @returns Inserted document
     */
    upsertDocument(uri: string, text: string, docType?: string, metadata?: Record<string, MetadataTypes>, options?: {
        force?: boolean;
    }): Promise<LocalDocument>;
    /**
     * Returns all documents in the index.
     * @remarks
     * Each document will contain all of the documents indexed chunks.
     * @returns Array of documents.
     */
    listDocuments(): Promise<LocalDocumentResult[]>;
    /**
     * Queries the index for documents similar to the given query.
     * @param query Text to query for.
     * @param options Optional. Query options.
     * @returns Array of document results.
     */
    queryDocuments(query: string, options?: DocumentQueryOptions): Promise<LocalDocumentResult[]>;
    beginUpdate(): Promise<void>;
    cancelUpdate(): void;
    createIndex(config?: CreateIndexConfig): Promise<void>;
    endUpdate(): Promise<void>;
    protected loadIndexData(): Promise<void>;
}
//# sourceMappingURL=LocalDocumentIndex.d.ts.map