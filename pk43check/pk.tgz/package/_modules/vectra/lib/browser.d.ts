/**
 * Browser entry point for Vectra.
 *
 * This module exports only browser-compatible components.
 * Node-specific components (LocalFileStorage, FileFetcher, WebFetcher) are excluded.
 *
 * For browser usage:
 * - Use `VirtualFileStorage` for in-memory storage (ephemeral)
 * - Use `IndexedDBStorage` for persistent browser storage
 * - Use `BrowserWebFetcher` for fetching web content
 */
export { LocalIndex, CreateIndexConfig } from './LocalIndex';
export { LocalDocumentIndex, LocalDocumentIndexConfig, DocumentQueryOptions } from './LocalDocumentIndex';
export { LocalDocument } from './LocalDocument';
export { LocalDocumentResult } from './LocalDocumentResult';
export { TextSplitter, TextSplitterConfig } from './TextSplitter';
export { GPT3Tokenizer } from './GPT3Tokenizer';
export { OpenAIEmbeddings, OpenAIEmbeddingsOptions, AzureOpenAIEmbeddingsOptions, OSSEmbeddingsOptions, BaseOpenAIEmbeddingsOptions } from './OpenAIEmbeddings';
export { MiniMaxEmbeddings, MiniMaxEmbeddingsOptions } from './MiniMaxEmbeddings';
export { TransformersEmbeddings, TransformersEmbeddingsOptions } from './TransformersEmbeddings';
export { TransformersTokenizer } from './TransformersTokenizer';
export { ItemSelector } from './ItemSelector';
export { EmbeddingsModel, EmbeddingsResponse, EmbeddingsResponseStatus, TextChunk, TextFetcher, IndexStats, IndexItem, MetadataFilter, MetadataTypes, QueryResult, Tokenizer, DocumentChunkMetadata, DocumentCatalogStats, DocumentTextSection, IndexData } from './types';
export { FileStorage, FileDetails, ListFilesFilter } from './storage/FileStorage';
export { FileStorageUtilities } from './storage/FileStorageUtilities';
export { FileType } from './storage/FileType';
export { VirtualFileStorage } from './storage/VirtualFileStorage';
export { IndexedDBStorage } from './storage/IndexedDBStorage';
export { BrowserWebFetcher, BrowserWebFetcherConfig } from './BrowserWebFetcher';
export { pathUtils } from './utils/pathUtils';
//# sourceMappingURL=browser.d.ts.map